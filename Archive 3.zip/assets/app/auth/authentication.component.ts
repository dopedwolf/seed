import {Component} from "@angular/core";

@Component ({
  selector: 'app-authentication',
  template: `<h1>Authentication</h1>`
})
export class AuthenticationComponent {

}
