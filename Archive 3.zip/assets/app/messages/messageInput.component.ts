import {Component} from '@angular/core';
import {NgForm} from '@angular/forms';

import {MessageService} from './message.service';
import {Message} from './message.model';


//the providers allows angular to create an instance of this service to be used in the private constructor below
@Component ({
  selector: 'app-message-input',
  templateUrl: './message-input.component.html'
})
export class MessageInputComponent {
  constructor(private messageService: MessageService) {}
  onSubmit(form: NgForm) {
    const message = new Message(form.value.content, 'Mateo');
    this.messageService.addMessage(message);
    form.resetForm();
  }
}
