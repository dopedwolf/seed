import {Routes, RouterModule} from "@angular/router"

import {MessagesComponent} from './messages/messages.component';
import {AuthenticationComponent} from './auth/authentication.component';

//pathMatch allows angular to always redirect to messages regardles of the input. (always redirects to messages when at the root path)
const APP_ROUTES: Routes = [
  { path: '', redirectTo: '/messages', pathMatch: 'full' },
  { path: 'messages', component: MessagesComponent },
  { path: 'auth', component: AuthenticationComponent }
];

//registers the routes in angular
//it needs to be reexported since the main one comes with no routes
export const routing = RouterModule.forRoot(APP_ROUTES);
